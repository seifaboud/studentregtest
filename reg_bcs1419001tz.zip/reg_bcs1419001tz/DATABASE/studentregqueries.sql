create database studentrecords;

use studentrecords;

create table login(
user_no int identity(1,1),
username varchar(255) collate sql_latin1_general_cp1_cs_as not null,
password varchar(255) collate sql_latin1_general_cp1_cs_as not null
)

create table student(
reg_no varchar(20) collate sql_latin1_general_cp1_cs_as not null,
primary key(reg_no),
student_name varchar(255) collate sql_latin1_general_cp1_cs_as not null,
birthdate date,
gender char,
phone varchar(20),
s_address varchar(255)
)

insert into login(username, password) values ('admin', 'admin123');

