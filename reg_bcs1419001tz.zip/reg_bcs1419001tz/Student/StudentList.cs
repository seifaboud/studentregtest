﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace reg_bcs1419001tz.Student
{
    public partial class StudentList : Form
    {
        public StudentList()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            SqlConnection conn = Connections.GetConnection();

            var viewlist = "SELECT * FROM [studentrecords].[dbo].[student]";

            SqlDataAdapter sda = new SqlDataAdapter(viewlist, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            foreach(DataRow item in dt.Rows)
            {
                int n = studentListView.Rows.Add();

                studentListView.Rows[n].Cells[0].Value = item["regno"].ToString();
                studentListView.Rows[n].Cells[1].Value = item["firstname"].ToString();
                studentListView.Rows[n].Cells[2].Value = item["lastname"].ToString();
                studentListView.Rows[n].Cells[3].Value = item["birthdate"].ToString();
                studentListView.Rows[n].Cells[4].Value = item["gender"].ToString();
                studentListView.Rows[n].Cells[5].Value = item["phone"].ToString();
                studentListView.Rows[n].Cells[6].Value = item["studentaddress"].ToString();
            }
        }

        private void StudentList_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void studentListView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            EditStudent editStudent = new EditStudent();
            editStudent.Show();
            editStudent.regnumber.Text = Convert.ToString(studentListView.Rows[0].Cells[0].Value);
            editStudent.fname.Text = Convert.ToString(studentListView.Rows[0].Cells[1].Value);
            editStudent.lname.Text = Convert.ToString(studentListView.Rows[0].Cells[2].Value);
            editStudent.dobpick.Value = Convert.ToDateTime(studentListView.Rows[0].Cells[3].Value);
            editStudent.gender.Text = Convert.ToString(studentListView.Rows[0].Cells[4].Value);
            editStudent.phonenumber.Text = Convert.ToString(studentListView.Rows[0].Cells[5].Value);
            editStudent.youraddress.Text = Convert.ToString(studentListView.Rows[0].Cells[6].Value);
        }
    }
}
