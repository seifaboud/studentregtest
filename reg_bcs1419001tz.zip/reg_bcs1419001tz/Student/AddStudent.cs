﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace reg_bcs1419001tz.Student
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
          
            
                SqlConnection conn = Connections.GetConnection();
                conn.Open();

                var insert = @"INSERT INTO [studentrecords].[dbo].[student]  VALUES('" + regno.Text + "', '" + firstname.Text + "', '" + lastname.Text + "', '" + dobPicker.Value + "', '" + genderBox.Text + "', '" + phone.Text + "', '" + address.Text + "')";

                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.ExecuteNonQueryAsync();

                conn.Close();

                MessageBox.Show("Operation Performed", "Notice", MessageBoxButtons.OK);

          
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearRecs();
        }

        private void ClearRecs()
        {
            regno.Clear();
            firstname.Clear();
            lastname.Clear();
            address.Clear();
            phone.Clear();
            regno.Focus();
        }
    }
}
