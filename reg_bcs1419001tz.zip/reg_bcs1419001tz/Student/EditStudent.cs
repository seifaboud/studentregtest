﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace reg_bcs1419001tz.Student
{
    public partial class EditStudent : Form
    {
        public EditStudent()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Connections.GetConnection();

            var search = "SELECT * FROM [studentrecords].[dbo].[student] WHERE [regno] = '"+txtSearch.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(search, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            foreach(DataRow item in dt.Rows)
            {
                regnumber.Text = item["regno"].ToString();
                fname.Text = item["firstname"].ToString();
                lname.Text = item["lastname"].ToString();
                dobpick.Value = Convert.ToDateTime(item["birthdate"].ToString());
                gender.Text = item["gender"].ToString();
                phonenumber.Text = item["phone"].ToString();
                youraddress.Text = item["studentaddress"].ToString();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Connections.GetConnection();
            conn.Open();

            var edit = @"UPDATE [studentrecords].[dbo].[student] SET [firstname] = '"+fname.Text+"', [lastname] = '"+lname.Text+"', [birthdate] = '"+dobpick.Value+"', [gender] = '"+gender.Text+"', [phone] = '"+phonenumber.Text+"', [studentaddress] = '"+youraddress.Text+"' WHERE [regno] = '"+regnumber.Text+"'";
            SqlCommand cmd = new SqlCommand(edit, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Operation Complete", "Edit", MessageBoxButtons.OK);
            conn.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Connections.GetConnection();
            conn.Open();

            var delete = @"DELETE FROM [studentrecords].[dbo].[student] WHERE [regno] = '"+regnumber.Text+"'";
            SqlCommand cmd = new SqlCommand(delete, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Delete Operation Complete", "Delete", MessageBoxButtons.OK);
            conn.Close();
        }
    }
}
