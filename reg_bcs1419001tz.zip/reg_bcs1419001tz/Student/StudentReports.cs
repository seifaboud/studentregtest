﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace reg_bcs1419001tz.Student
{
    public partial class StudentReports : Form
    {
        public StudentReports()
        {
            InitializeComponent();
        }

        ReportDocument crypt = new ReportDocument();


        private void StudentReports_Load(object sender, EventArgs e)
        {
            crypt.Load(@"D:\C#Spiel\reg_bcs1419001tz\StudentReport.rpt");
            SqlConnection conn = Connections.GetConnection();
            conn.Open();
            DataSet dst = new DataSet();
            var fillRecords = "SELECT * FROM [studentrecords].[dbo].[student]  ORDER BY regno";
            SqlDataAdapter sda = new SqlDataAdapter(fillRecords, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            crypt.SetDataSource(dt);
            studentListViewer.ReportSource = crypt;
        }
    }
}
