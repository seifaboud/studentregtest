﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace reg_bcs1419001tz
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Connections.GetConnection();
            conn.Open();

            var login = "SELECT * FROM [studentrecords].[dbo].[login] WHERE username = '"+txtUsername.Text+"' AND password = '"+txtPassword.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(login, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                this.Hide();
                StudMain sm = new StudMain();
                sm.Show();
            }

            else
            {
                MessageBox.Show("Invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
